New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title 'Intune App Sandbox' -Body 'Pre-configurations and file decoding initiated'
If (!(Test-Path -Path C:\Temp -PathType Container))
{
	New-Item -Path C:\Temp -ItemType Directory
}
Copy-Item -Path "C:\Users\WDAGUtilityAccount\Desktop\Install-7-zip-winget-PSADT\Deploy-Application.intunewin" -Destination C:\Temp
$Decoder = Start-Process -FilePath C:\Users\WDAGUtilityAccount\Desktop\bin\IntuneWinAppUtilDecoder.exe -ArgumentList "C:\Temp\Deploy-Application.intunewin /s" -NoNewWindow -PassThru -Wait

Rename-Item -Path "C:\Temp\Deploy-Application.intunewin.decoded" -NewName 'Deploy-Application.zip' -Force;
Expand-Archive -Path "C:\Temp\Deploy-Application.zip" -Destination C:\Temp -Force;
Remove-Item -Path "C:\Temp\Deploy-Application.zip" -Force;
New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title 'Intune App Sandbox' -Body 'Decoding finished!'
Start-Sleep 1
if($True)
{
    New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title 'Intune App Sandbox' -Body 'Preparing WinGet'
    Start-Sleep 1
    New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title 'Intune App Sandbox' -Body 'Installing VC_redist.x64.exe'
    Start-Process -FilePath C:\Users\WDAGUtilityAccount\Desktop\bin\WinGet\VC_redist.x64.exe -argumentlist "/quiet /norestart" -Wait
    New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title 'Intune App Sandbox' -Body 'Installing Microsoft.VCLibs.140.00.UWPDesktop'
    Add-AppxProvisionedPackage -Online -PackagePath C:\Users\WDAGUtilityAccount\Desktop\bin\WinGet\Microsoft.VCLibs.x64.14.00.Desktop.appx -SkipLicense | Out-Null
    New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title 'Intune App Sandbox' -Body 'Installing WinGet'
    Add-AppxProvisionedPackage -Online -PackagePath C:\Users\WDAGUtilityAccount\Desktop\bin\WinGet\Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.msixbundle -SkipLicense | Out-Null
}
$TaskActionArgument = '-ex bypass "powershell {New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title {Intune App Sandbox} -Body {Installing software};
& C:\Temp\Deploy-Application.exe};
New-Item C:\Temp\$Lastexitcode.code -force;
New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title {Intune App Sandbox} -Body """Installation completed with code: $LASTEXITCODE""""'
$Trigger = New-ScheduledTaskTrigger -Once -At $(Get-Date).AddSeconds(15)
$User = "SYSTEM"
$Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $TaskActionArgument
$Settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit "01:00" -AllowStartIfOnBatteries
Register-ScheduledTask -TaskName "Install App" -Trigger $Trigger -User $User -Action $Action -Settings $Settings -Force