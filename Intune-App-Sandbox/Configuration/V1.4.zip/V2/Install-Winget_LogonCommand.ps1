New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title 'Intune App Sandbox' -Body 'Pre-configurations and file decoding initiated'
If (!(Test-Path -Path C:\Temp -PathType Container))
{
	New-Item -Path C:\Temp -ItemType Directory
}
Copy-Item -Path "C:\Users\WDAGUtilityAccount\Desktop\Install-Winget\Install-Winget.intunewin" -Destination C:\Temp
$Decoder = Start-Process -FilePath C:\Users\WDAGUtilityAccount\Desktop\bin\IntuneWinAppUtilDecoder.exe -ArgumentList "C:\Temp\Install-Winget.intunewin /s" -NoNewWindow -PassThru -Wait

Rename-Item -Path "C:\Temp\Install-Winget.intunewin.decoded" -NewName 'Install-Winget.zip' -Force;
Expand-Archive -Path "C:\Temp\Install-Winget.zip" -Destination C:\Temp -Force;
Remove-Item -Path "C:\Temp\Install-Winget.zip" -Force;
New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title 'Intune App Sandbox' -Body 'Decoding finished!'
# register detection script as scheduled task
if($False)
{
    # register script as scheduled task
    $TaskActionArgument = '-ex bypass "powershell {New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title {Intune App Sandbox} -Body {Installing software};
    & C:\Temp\Install-Winget.ps1};
    New-Item C:\Temp\$Lastexitcode.code -force;
    New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title {Intune App Sandbox} -Body """Installation completed with code: $LASTEXITCODE""";
    Start-ScheduledTask -TaskName {Detect App}"'
    $User = "SYSTEM"
    $Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $TaskActionArgument
    $Settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit "01:00" -AllowStartIfOnBatteries
    Register-ScheduledTask -TaskName "Install App" -User $User -Action $Action -Settings $Settings -Force
    $TaskActionArgument = '-ex bypass "powershell {New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title {Intune App Sandbox} -Body {Detecting software};
    & C:\Temp\Install-Winget_Detection.ps1};
    New-Item C:\Temp\$LastExitcode.detectioncode -force;
    New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title {Intune App Sandbox} -Body """Detection completed with code: $LASTEXITCODE"""
    if($LASTEXITCODE -eq 1){Start-ScheduledTask -TaskName {Install app}}"'
    $Trigger = New-ScheduledTaskTrigger -Once -At $(Get-Date).AddSeconds(15)
    $User = "SYSTEM"
    $Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $TaskActionArgument
    $Settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit "01:00" -AllowStartIfOnBatteries
    Register-ScheduledTask -TaskName "Detect App" -Trigger $Trigger -User $User -Action $Action -Settings $Settings -Force

}else{
    $TaskActionArgument = '-ex bypass "powershell {New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title {Intune App Sandbox} -Body {Installing software};
    & C:\Temp\Install-Winget.ps1};
    New-Item C:\Temp\$Lastexitcode.code -force;
    New-ToastNotification -XmlPath C:\Users\WDAGUtilityAccount\Desktop\bin\toast.xml -Title {Intune App Sandbox} -Body """Installation completed with code: $LASTEXITCODE""""'
    $Trigger = New-ScheduledTaskTrigger -Once -At $(Get-Date).AddSeconds(15)
    $User = "SYSTEM"
    $Action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $TaskActionArgument
    $Settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit "01:00" -AllowStartIfOnBatteries
    Register-ScheduledTask -TaskName "Install App" -Trigger $Trigger -User $User -Action $Action -Settings $Settings -Force
}