Set-ExecutionPolicy Bypass -Force;
new-item C:\Windows\System32\WindowsPowerShell\v1.0\Profile.ps1;
Set-Content -Path C:\Windows\System32\WindowsPowerShell\v1.0\Profile.ps1 -Value '. C:\Users\WDAGUtilityAccount\Desktop\bin\New-ToastNotification.ps1';
powershell -file 'C:\Users\WDAGUtilityAccount\Desktop\bin\Install-Winget_LogonCommand.ps1'